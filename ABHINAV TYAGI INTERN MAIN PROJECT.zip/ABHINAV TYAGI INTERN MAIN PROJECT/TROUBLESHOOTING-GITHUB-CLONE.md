# Troubleshooting GitHub Clone Issues

## **🔧 Common Issues and Solutions**

### **Issue 1: Git Not Found**
**Error:** `'git' is not recognized as an internal or external command`

**Solutions:**
- Install Git: https://git-scm.com/download/win
- Or use Visual Studio's built-in Git
- Or download ZIP from GitHub instead

### **Issue 2: Repository Not Found**
**Error:** `Repository not found` or `Access denied`

**Solutions:**
- Check if repository is public
- Verify GitHub URL is correct
- Use HTTPS URL format: `https://github.com/username/repo.git`

### **Issue 3: Visual Studio Won't Open Project**
**Problem:** Project cloned but won't open

**Solutions:**
- Look for `.sln` file in the cloned folder
- Double-click the `.sln` file
- Or open Visual Studio → File → Open → Project/Solution

### **Issue 4: NuGet Packages Not Restoring**
**Problem:** Build errors about missing packages

**Solutions:**
\`\`\`bash
# In Package Manager Console:
Update-Package -reinstall

# Or right-click solution:
# Restore NuGet Packages
\`\`\`

### **Issue 5: Database Connection After Clone**
**Problem:** Application runs but can't connect to database

**Solutions:**
- Check `appsettings.json` has correct connection string
- Run database setup scripts in SSMS
- Verify SQL Server connection: 10.7.74.186

## **🆘 Emergency Backup Method**
If Git clone fails:
1. Go to GitHub repository in browser
2. Click **Code** → **Download ZIP**
3. Extract ZIP file
4. Open `.sln` file in Visual Studio
