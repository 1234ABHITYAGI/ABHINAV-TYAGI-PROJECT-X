using ConferenceRoomBooking.Services;

namespace ConferenceRoomBooking.Middleware
{
    public class AdminAccessMiddleware
    {
        private readonly RequestDelegate _next;

        public AdminAccessMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context, IAdminAccessService adminAccessService)
        {
            var path = context.Request.Path.Value?.ToLower();

            // Check if accessing admin routes
            if (path != null && path.StartsWith("/admin"))
            {
                var userId = context.Session.GetInt32("UserId");
                var userRole = context.Session.GetString("UserRole");
                var adminAccess = context.Session.GetString("AdminAccess");

                // If not logged in, redirect to login
                if (userId == null)
                {
                    context.Response.Redirect("/Account/Login");
                    return;
                }

                // If not admin role, check for admin access
                if (userRole != "Admin" && adminAccess != "true")
                {
                    context.Response.Redirect("/AdminAccess/Authenticate");
                    return;
                }

                // Check if admin access is still valid
                if (adminAccess == "true" && userRole != "Admin")
                {
                    var isStillValid = await adminAccessService.IsAccessStillValidAsync();
                    if (!isStillValid)
                    {
                        context.Session.Remove("AdminAccess");
                        context.Response.Redirect("/AdminAccess/LockedOut");
                        return;
                    }
                }
            }

            await _next(context);
        }
    }
}
