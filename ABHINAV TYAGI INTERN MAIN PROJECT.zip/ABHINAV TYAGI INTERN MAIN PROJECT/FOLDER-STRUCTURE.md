# Project Folder Structure

\`\`\`
ConferenceRoomBooking/
├── Controllers/
│   ├── HomeController.cs
│   ├── AccountController.cs
│   ├── BookingController.cs
│   ├── AdminController.cs
│   └── DatabaseTestController.cs
├── Models/
│   ├── User.cs
│   ├── ConferenceRoom.cs
│   ├── Booking.cs
│   └── BookingViewModel.cs
├── Data/
│   └── ApplicationDbContext.cs
├── Services/
│   ├── IPermissionService.cs
│   ├── PermissionService.cs
│   ├── IAdminAccessService.cs
│   └── AdminAccessService.cs
├── Views/
│   ├── Shared/
│   │   ├── _Layout.cshtml
│   │   └── _AdminLayout.cshtml
│   ├── Home/
│   │   └── Index.cshtml
│   ├── Account/
│   │   └── Login.cshtml
│   ├── Booking/
│   │   ├── Index.cshtml
│   │   ├── Create.cshtml
│   │   └── Calendar.cshtml
│   └── Admin/
│       ├── Index.cshtml
│       ├── Rooms.cshtml
│       ├── CreateRoom.cshtml
│       └── EditRoom.cshtml
├── wwwroot/
│   ├── css/
│   ├── js/
│   └── lib/
├── scripts/ (Database Scripts)
│   ├── complete-database-setup.sql
│   ├── test-connection.sql
│   └── final-verification.sql
├── appsettings.json
├── Program.cs
└── ConferenceRoomBooking.csproj
