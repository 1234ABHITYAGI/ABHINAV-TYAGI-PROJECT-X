using Microsoft.EntityFrameworkCore;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace ConferenceRoomBooking.Services
{
    public class PermissionService : IPermissionService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<PermissionService> _logger;
        
        public PermissionService(ApplicationDbContext context, ILogger<PermissionService> logger)
        {
            _context = context;
            _logger = logger;
        }
        
        public bool HasPermission(int userId, string permission)
        {
            return _context.UserRoles
                .Where(ur => ur.UserId == userId)
                .Join(_context.RolePermissions, ur => ur.RoleId, rp => rp.RoleId, (ur, rp) => rp)
                .Join(_context.Permissions, rp => rp.PermissionId, p => p.Id, (rp, p) => p)
                .Any(p => p.Name == permission);
        }

        public async Task<bool> HasPermissionAsync(int userId, string permission)
        {
            return await _context.UserRoles
                .Where(ur => ur.UserId == userId)
                .Join(_context.RolePermissions, ur => ur.RoleId, rp => rp.RoleId, (ur, rp) => rp)
                .Join(_context.Permissions, rp => rp.PermissionId, p => p.Id, (rp, p) => p)
                .AnyAsync(p => p.Name == permission);
        }

        public List<string> GetUserPermissions(int userId)
        {
            return _context.UserRoles
                .Where(ur => ur.UserId == userId)
                .Join(_context.RolePermissions, ur => ur.RoleId, rp => rp.RoleId, (ur, rp) => rp)
                .Join(_context.Permissions, rp => rp.PermissionId, p => p.Id, (rp, p) => p)
                .Select(p => p.Name)
                .ToList();
        }

        public async Task<List<string>> GetUserPermissionsAsync(int userId)
        {
            return await _context.UserRoles
                .Where(ur => ur.UserId == userId)
                .Join(_context.RolePermissions, ur => ur.RoleId, rp => rp.RoleId, (ur, rp) => rp)
                .Join(_context.Permissions, rp => rp.PermissionId, p => p.Id, (rp, p) => p)
                .Select(p => p.Name)
                .ToListAsync();
        }
        
        public async Task<List<Role>> GetUserRolesAsync(int userId)
        {
            try
            {
                var roles = await _context.UserRoles
                    .Where(ur => ur.UserId == userId && ur.IsActive)
                    .Include(ur => ur.Role)
                    .Select(ur => ur.Role)
                    .Where(r => r.IsActive)
                    .ToListAsync();
                
                return roles;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting roles for user {UserId}", userId);
                return new List<Role>();
            }
        }
        
        public async Task<bool> IsInRoleAsync(int userId, string roleName)
        {
            try
            {
                var isInRole = await _context.UserRoles
                    .Where(ur => ur.UserId == userId && ur.IsActive)
                    .Join(_context.Roles.Where(r => r.IsActive && r.Name == roleName),
                          ur => ur.RoleId,
                          r => r.Id,
                          (ur, r) => r)
                    .AnyAsync();
                
                return isInRole;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking role {RoleName} for user {UserId}", roleName, userId);
                return false;
            }
        }
        
        public async Task<bool> AssignRoleToUserAsync(int userId, int roleId, int assignedBy)
        {
            try
            {
                // Check if user already has this role
                var existingRole = await _context.UserRoles
                    .FirstOrDefaultAsync(ur => ur.UserId == userId && ur.RoleId == roleId);
                
                if (existingRole != null)
                {
                    if (!existingRole.IsActive)
                    {
                        existingRole.IsActive = true;
                        existingRole.AssignedAt = DateTime.Now;
                        existingRole.AssignedBy = assignedBy;
                    }
                    return true;
                }
                
                var userRole = new UserRole
                {
                    UserId = userId,
                    RoleId = roleId,
                    AssignedBy = assignedBy,
                    AssignedAt = DateTime.Now,
                    IsActive = true
                };
                
                _context.UserRoles.Add(userRole);
                await _context.SaveChangesAsync();
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error assigning role {RoleId} to user {UserId}", roleId, userId);
                return false;
            }
        }
        
        public async Task<bool> RemoveRoleFromUserAsync(int userId, int roleId)
        {
            try
            {
                var userRole = await _context.UserRoles
                    .FirstOrDefaultAsync(ur => ur.UserId == userId && ur.RoleId == roleId && ur.IsActive);
                
                if (userRole != null)
                {
                    userRole.IsActive = false;
                    await _context.SaveChangesAsync();
                    return true;
                }
                
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error removing role {RoleId} from user {UserId}", roleId, userId);
                return false;
            }
        }
        
        public async Task<List<User>> GetUsersInRoleAsync(string roleName)
        {
            try
            {
                var users = await _context.UserRoles
                    .Where(ur => ur.IsActive)
                    .Join(_context.Roles.Where(r => r.IsActive && r.Name == roleName),
                          ur => ur.RoleId,
                          r => r.Id,
                          (ur, r) => ur)
                    .Include(ur => ur.User)
                    .Select(ur => ur.User)
                    .Where(u => u.IsActive)
                    .ToListAsync();
                
                return users;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting users in role {RoleName}", roleName);
                return new List<User>();
            }
        }
    }
}
