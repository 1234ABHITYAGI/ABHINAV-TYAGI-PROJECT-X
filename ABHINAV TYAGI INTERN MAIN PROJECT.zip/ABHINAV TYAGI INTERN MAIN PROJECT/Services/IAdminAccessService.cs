namespace ConferenceRoomBooking.Services
{
    public interface IAdminAccessService
    {
        Task<bool> ValidateAccessCodeAsync(string accessCode);
        Task<bool> ChangeAccessCodeAsync(string currentCode, string newCode);
        Task<bool> IsAccessStillValidAsync();
    }
}
