namespace ConferenceRoomBooking.Services
{
    public interface IPermissionService
    {
        bool HasPermission(int userId, string permission);
        Task<bool> HasPermissionAsync(int userId, string permission);
        List<string> GetUserPermissions(int userId);
        Task<List<string>> GetUserPermissionsAsync(int userId);
    }
}
