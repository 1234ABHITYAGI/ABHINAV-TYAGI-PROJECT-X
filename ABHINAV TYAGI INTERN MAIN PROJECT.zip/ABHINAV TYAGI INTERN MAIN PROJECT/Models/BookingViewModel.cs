using System.ComponentModel.DataAnnotations;

namespace ConferenceRoomBooking.Models
{
    public class BookingViewModel
    {
        [Required]
        public int RoomId { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [StringLength(1000)]
        public string? Description { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }
    }
}
