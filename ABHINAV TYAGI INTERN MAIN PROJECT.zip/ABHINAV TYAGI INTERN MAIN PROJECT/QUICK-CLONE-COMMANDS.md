# Quick Clone Commands

## For Command Line Users

### Step 1: Open Command Prompt as Administrator
\`\`\`bash
# Press Windows + R, type "cmd", press Ctrl+Shift+Enter
\`\`\`

### Step 2: Navigate and Clone
\`\`\`bash
# Go to C: drive
cd C:\

# Create Projects folder
mkdir Projects
cd Projects

# Clone the repository
git clone https://github.com/AbhinavTyagi2612/ABHINAV-INTERNSHIP-FINAL-PROJECT.git

# Enter project folder
cd ABHINAV-INTERNSHIP-FINAL-PROJECT

# List files to verify
dir
\`\`\`

### Step 3: Open in Visual Studio
\`\`\`bash
# Open the solution file
start ConferenceRoomBooking.sln
\`\`\`

## Alternative: PowerShell Commands

### Step 1: Open PowerShell as Administrator
\`\`\`powershell
# Press Windows + X, select "Windows PowerShell (Admin)"
