using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using Microsoft.EntityFrameworkCore;

namespace ConferenceRoomBooking.Controllers
{
    public class DatabaseTestController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DatabaseTestController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> TestConnection()
        {
            try
            {
                // Test database connection
                await _context.Database.OpenConnectionAsync();
                await _context.Database.CloseConnectionAsync();

                ViewBag.ConnectionStatus = "Success";
                ViewBag.Message = "Database connection successful!";

                // Get some basic stats
                var stats = new
                {
                    UsersCount = await _context.Users.CountAsync(),
                    RoomsCount = await _context.ConferenceRooms.CountAsync(),
                    BookingsCount = await _context.Bookings.CountAsync(),
                    RolesCount = await _context.Roles.CountAsync()
                };

                ViewBag.Stats = stats;
            }
            catch (Exception ex)
            {
                ViewBag.ConnectionStatus = "Failed";
                ViewBag.Message = $"Database connection failed: {ex.Message}";
                ViewBag.Stats = null;
            }

            return View();
        }

        public async Task<IActionResult> DatabaseInfo()
        {
            try
            {
                var connectionString = _context.Database.GetConnectionString();
                var databaseName = _context.Database.GetDbConnection().Database;

                ViewBag.ConnectionString = connectionString;
                ViewBag.DatabaseName = databaseName;
                ViewBag.ProviderName = _context.Database.ProviderName;

                // Test query
                var canConnect = await _context.Database.CanConnectAsync();
                ViewBag.CanConnect = canConnect;

                if (canConnect)
                {
                    var tableNames = new List<string>();
                    
                    // Get table information
                    var tables = await _context.Database.SqlQueryRaw<string>(
                        "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'"
                    ).ToListAsync();
                    
                    ViewBag.Tables = tables;
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }

            return View();
        }
    }
}
