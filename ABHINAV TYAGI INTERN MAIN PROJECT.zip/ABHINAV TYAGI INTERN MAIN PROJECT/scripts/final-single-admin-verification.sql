-- Final verification with single admin setup
USE TestIPI;
GO

PRINT '=== CONFERENCE ROOM BOOKING SYSTEM - SINGLE ADMIN SETUP ===';
PRINT '';

-- Check Users and their roles
PRINT '1. USER ROLES:';
SELECT 
    '   ' + u.Name + ' (' + u.Username + ') - ' + 
    CASE WHEN u.IsAdmin = 1 THEN '👑 ADMIN' ELSE '👤 USER' END as UserInfo
FROM Users u
WHERE u.IsActive = 1
ORDER BY u.IsAdmin DESC, u.Name;

PRINT '';

-- Detailed role verification
PRINT '2. ROLE ASSIGNMENTS:';
SELECT 
    '   ' + u.Name + ' → ' + ISNULL(STRING_AGG(r.Name, ', '), 'No roles assigned') as RoleAssignment
FROM Users u
LEFT JOIN UserRoles ur ON u.Id = ur.UserId AND ur.IsActive = 1
LEFT JOIN Roles r ON ur.RoleId = r.Id
WHERE u.IsActive = 1
GROUP BY u.Id, u.Name
ORDER BY u.Name;

PRINT '';

-- Admin verification
PRINT '3. ADMIN STATUS:';
SELECT 
    '   ADMIN: ' + u.Name + ' (' + u.Username + ')' as AdminInfo
FROM Users u
WHERE u.IsAdmin = 1 AND u.IsActive = 1;

PRINT '';

-- User count by role
PRINT '4. USER STATISTICS:';
SELECT 
    '   Total Users: ' + CAST(COUNT(*) AS VARCHAR) as UserStats
FROM Users 
WHERE IsActive = 1;

SELECT 
    '   Admins: ' + CAST(COUNT(*) AS VARCHAR) as AdminStats
FROM Users 
WHERE IsActive = 1 AND IsAdmin = 1;

SELECT 
    '   Regular Users: ' + CAST(COUNT(*) AS VARCHAR) as RegularUserStats
FROM Users 
WHERE IsActive = 1 AND IsAdmin = 0;

PRINT '';

-- System Status
PRINT '5. SYSTEM STATUS:';
PRINT '   ✅ Single Admin: Abhinav Tyagi';
PRINT '   ✅ All others: Regular Users';
PRINT '   ✅ No Super Admin or Manager roles';
PRINT '   ✅ Simple role structure implemented';

PRINT '';
PRINT '🎯 SINGLE ADMIN SYSTEM READY! 🎯';
PRINT '';
PRINT 'ADMIN LOGIN:';
PRINT '   Username: abhinav';
PRINT '   Password: admin123';
PRINT '   Name: Abhinav Tyagi';
PRINT '';
PRINT 'ALL OTHER USERS: Regular access only';
