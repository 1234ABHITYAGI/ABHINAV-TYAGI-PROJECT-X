-- Update existing users with Indian names or insert new ones
USE TestIPI;
GO

-- Clear existing users (optional - only if you want to start fresh)
-- DELETE FROM UserRoles;
-- DELETE FROM Bookings;
-- DELETE FROM Users;

-- Insert Indian users
INSERT INTO Users (Name, Email, Username, Password, IsAdmin, IsActive, CreatedAt) VALUES
('Rajesh Kumar', 'rajesh.kumar@company.com', 'rajesh', 'admin123', 1, 1, GETDATE()),
('Abhinav Sharma', 'abhinav.sharma@company.com', 'abhinav', 'admin123', 1, 1, GETDATE()),
('Rohit Gupta', 'rohit.gupta@company.com', 'rohit', 'user123', 0, 1, GETDATE()),
('Priya Singh', 'priya.singh@company.com', 'priya', 'user123', 0, 1, GETDATE()),
('Vikram Patel', 'vikram.patel@company.com', 'vikram', 'user123', 0, 1, GETDATE()),
('Anita Verma', 'anita.verma@company.com', 'anita', 'user123', 0, 1, GETDATE()),
('Suresh Reddy', 'suresh.reddy@company.com', 'suresh', 'user123', 0, 1, GETDATE()),
('Kavya Nair', 'kavya.nair@company.com', 'kavya', 'user123', 0, 1, GETDATE()),
('Arjun Mehta', 'arjun.mehta@company.com', 'arjun', 'user123', 0, 1, GETDATE()),
('Deepika Joshi', 'deepika.joshi@company.com', 'deepika', 'user123', 0, 1, GETDATE()),
('Karan Agarwal', 'karan.agarwal@company.com', 'karan', 'user123', 0, 1, GETDATE()),
('Sneha Iyer', 'sneha.iyer@company.com', 'sneha', 'user123', 0, 1, GETDATE());

-- Update conference rooms with Indian river names
UPDATE ConferenceRooms SET 
    Name = 'Ganga Conference Room',
    Description = 'Executive meeting room with video conferencing facilities',
    Location = '10th Floor, Tower A'
WHERE Id = 1;

UPDATE ConferenceRooms SET 
    Name = 'Yamuna Meeting Hall',
    Description = 'Large conference room with presentation equipment',
    Location = '5th Floor, Tower B'
WHERE Id = 2;

UPDATE ConferenceRooms SET 
    Name = 'Saraswati Discussion Room',
    Description = 'Medium meeting room with whiteboard and projector',
    Location = '3rd Floor, Tower A'
WHERE Id = 3;

UPDATE ConferenceRooms SET 
    Name = 'Kaveri Training Room',
    Description = 'Training room with modern AV equipment',
    Location = '2nd Floor, Training Wing'
WHERE Id = 4;

-- Insert additional Indian-themed conference rooms
INSERT INTO ConferenceRooms (Name, Description, Capacity, Location, IsActive, CreatedAt) VALUES
('Narmada Boardroom', 'Premium boardroom for executive meetings', 15, '12th Floor, Executive Wing', 1, GETDATE()),
('Godavari Innovation Lab', 'Creative space with flexible seating and collaboration tools', 10, '4th Floor, Innovation Center', 1, GETDATE()),
('Krishna Meeting Pod', 'Small meeting space for quick discussions', 4, '6th Floor, Collaboration Zone', 1, GETDATE()),
('Brahmaputra Conference Hall', 'Large auditorium-style meeting room', 50, '1st Floor, Main Building', 1, GETDATE());

-- Assign roles to Indian users
-- Make Rajesh and Abhinav Super Admins
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Username IN ('rajesh', 'abhinav') AND r.Name = 'Super Admin';

-- Make Rohit and Priya Admins
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Username IN ('rohit', 'priya') AND r.Name = 'Admin';

-- Make Vikram and Anita Managers
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Username IN ('vikram', 'anita') AND r.Name = 'Manager';

-- Make others regular Users
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Username IN ('suresh', 'kavya', 'arjun', 'deepika', 'karan', 'sneha') AND r.Name = 'User';

-- Insert sample bookings with Indian context
DECLARE @Tomorrow DATETIME2 = DATEADD(DAY, 1, CAST(GETDATE() AS DATE));

INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status, CreatedAt) VALUES
-- Rohit's bookings
((SELECT Id FROM Users WHERE Username = 'rohit'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Ganga Conference Room'), 
 'Sprint Planning Meeting', 
 'Quarterly sprint planning for development team', 
 DATEADD(HOUR, 9, @Tomorrow), 
 DATEADD(HOUR, 11, @Tomorrow), 
 'Confirmed', 
 GETDATE()),

-- Priya's bookings
((SELECT Id FROM Users WHERE Username = 'priya'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Yamuna Meeting Hall'), 
 'Client Presentation', 
 'Product demo for potential client from Mumbai', 
 DATEADD(HOUR, 14, @Tomorrow), 
 DATEADD(HOUR, 16, @Tomorrow), 
 'Confirmed', 
 GETDATE()),

-- Vikram's bookings
((SELECT Id FROM Users WHERE Username = 'vikram'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Saraswati Discussion Room'), 
 'Team Standup', 
 'Daily team standup meeting', 
 DATEADD(HOUR, 10, @Tomorrow), 
 DATEADD(HOUR, 11, @Tomorrow), 
 'Confirmed', 
 GETDATE()),

-- Anita's bookings
((SELECT Id FROM Users WHERE Username = 'anita'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Kaveri Training Room'), 
 'New Employee Orientation', 
 'Orientation session for new joiners', 
 DATEADD(HOUR, 9, DATEADD(DAY, 2, @Tomorrow)), 
 DATEADD(HOUR, 12, DATEADD(DAY, 2, @Tomorrow)), 
 'Confirmed', 
 GETDATE()),

-- Suresh's bookings
((SELECT Id FROM Users WHERE Username = 'suresh'), 
 (SELECT Id FROM ConferenceRooms WHERE Name = 'Narmada Boardroom'), 
 'Budget Review Meeting', 
 'Quarterly budget review with finance team', 
 DATEADD(HOUR, 15, @Tomorrow), 
 DATEADD(HOUR, 17, @Tomorrow), 
 'Confirmed', 
 GETDATE());

PRINT 'Indian users and data seeded successfully!';

-- Verification
SELECT 'Users Created' as Info, COUNT(*) as Count FROM Users WHERE IsActive = 1;
SELECT 'Conference Rooms' as Info, COUNT(*) as Count FROM ConferenceRooms WHERE IsActive = 1;
SELECT 'Sample Bookings' as Info, COUNT(*) as Count FROM Bookings WHERE Status = 'Confirmed';

-- Show user details
SELECT 
    u.Name,
    u.Username,
    u.Email,
    CASE WHEN u.IsAdmin = 1 THEN 'Yes' ELSE 'No' END as IsAdmin,
    STRING_AGG(r.Name, ', ') as Roles
FROM Users u
LEFT JOIN UserRoles ur ON u.Id = ur.UserId AND ur.IsActive = 1
LEFT JOIN Roles r ON ur.RoleId = r.Id
WHERE u.IsActive = 1
GROUP BY u.Id, u.Name, u.Username, u.Email, u.IsAdmin
ORDER BY u.Name;
