-- Step 5: Create Useful Views and Stored Procedures
USE ConferenceRoomBookingDb;
GO

-- View: Active Bookings with User and Room Details
CREATE VIEW vw_ActiveBookings AS
SELECT 
    b.Id,
    b.Title,
    b.Description,
    b.StartTime,
    b.EndTime,
    b.Status,
    b.CreatedAt,
    u.Name AS UserName,
    u.Email AS UserEmail,
    cr.Name AS RoomName,
    cr.Location AS RoomLocation,
    cr.Capacity AS RoomCapacity,
    DATEDIFF(MINUTE, b.StartTime, b.EndTime) AS DurationMinutes
FROM Bookings b
INNER JOIN Users u ON b.UserId = u.Id
INNER JOIN ConferenceRooms cr ON b.ConferenceRoomId = cr.Id
WHERE b.Status = 'Confirmed' AND b.StartTime > GETDATE();
GO

-- View: Room Utilization Statistics
CREATE VIEW vw_RoomUtilization AS
SELECT 
    cr.Id,
    cr.Name,
    cr.Location,
    cr.Capacity,
    COUNT(b.Id) AS TotalBookings,
    COUNT(CASE WHEN b.Status = 'Confirmed' THEN 1 END) AS ConfirmedBookings,
    COUNT(CASE WHEN b.Status = 'Cancelled' THEN 1 END) AS CancelledBookings,
    AVG(CAST(DATEDIFF(MINUTE, b.StartTime, b.EndTime) AS FLOAT)) AS AvgDurationMinutes
FROM ConferenceRooms cr
LEFT JOIN Bookings b ON cr.Id = b.ConferenceRoomId
WHERE cr.IsActive = 1
GROUP BY cr.Id, cr.Name, cr.Location, cr.Capacity;
GO

-- Stored Procedure: Check Room Availability
CREATE PROCEDURE sp_CheckRoomAvailability
    @RoomId INT,
    @StartTime DATETIME2,
    @EndTime DATETIME2,
    @ExcludeBookingId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @ConflictCount INT;
    
    SELECT @ConflictCount = COUNT(*)
    FROM Bookings
    WHERE ConferenceRoomId = @RoomId
      AND Status = 'Confirmed'
      AND (@ExcludeBookingId IS NULL OR Id != @ExcludeBookingId)
      AND (
          (@StartTime >= StartTime AND @StartTime < EndTime) OR
          (@EndTime > StartTime AND @EndTime <= EndTime) OR
          (@StartTime <= StartTime AND @EndTime >= EndTime)
      );
    
    IF @ConflictCount = 0
        SELECT 1 AS IsAvailable, 'Room is available' AS Message;
    ELSE
        SELECT 0 AS IsAvailable, 'Room is not available for the selected time' AS Message;
END;
GO

-- Stored Procedure: Get User Booking Statistics
CREATE PROCEDURE sp_GetUserBookingStats
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        COUNT(*) AS TotalBookings,
        COUNT(CASE WHEN Status = 'Confirmed' THEN 1 END) AS ConfirmedBookings,
        COUNT(CASE WHEN Status = 'Cancelled' THEN 1 END) AS CancelledBookings,
        COUNT(CASE WHEN Status = 'Completed' THEN 1 END) AS CompletedBookings,
        COUNT(CASE WHEN StartTime > GETDATE() AND Status = 'Confirmed' THEN 1 END) AS UpcomingBookings,
        AVG(CAST(DATEDIFF(MINUTE, StartTime, EndTime) AS FLOAT)) AS AvgDurationMinutes
    FROM Bookings
    WHERE UserId = @UserId;
END;
GO

PRINT 'Views and stored procedures created successfully!';
