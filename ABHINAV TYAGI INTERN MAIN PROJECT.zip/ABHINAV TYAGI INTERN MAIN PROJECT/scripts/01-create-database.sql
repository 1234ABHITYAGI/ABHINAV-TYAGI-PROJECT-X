-- Step 1: Create the Database
USE master;
GO

-- Drop database if it exists (for development)
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'ConferenceRoomBookingDb')
BEGIN
    ALTER DATABASE ConferenceRoomBookingDb SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ConferenceRoomBookingDb;
END
GO

-- Create new database
CREATE DATABASE ConferenceRoomBookingDb;
GO

-- Use the new database
USE ConferenceRoomBookingDb;
GO

PRINT 'Database ConferenceRoomBookingDb created successfully!';
