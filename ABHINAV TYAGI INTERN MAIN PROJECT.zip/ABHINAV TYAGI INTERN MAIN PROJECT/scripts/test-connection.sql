-- Test Connection Script for your SQL Server
-- Run this script in SQL Server Management Studio to verify connection

-- Connect to your server: 10.7.74.186
-- Login: INTERN
-- Password: Intern@123
-- Database: Test_IPI

-- 1. Test if you can connect and see databases
SELECT name FROM sys.databases WHERE name = 'Test_IPI';

-- 2. Use your database
USE Test_IPI;
GO

-- 3. Check current user and permissions
SELECT 
    SYSTEM_USER as CurrentUser,
    USER_NAME() as DatabaseUser,
    IS_SRVROLEMEMBER('sysadmin') as IsSysAdmin,
    IS_MEMBER('db_owner') as IsDbOwner,
    IS_MEMBER('db_datareader') as IsDataReader,
    IS_MEMBER('db_datawriter') as IsDataWriter;

-- 4. Test creating a simple table (to verify permissions)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'TestConnection')
BEGIN
    CREATE TABLE TestConnection (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        TestMessage NVARCHAR(100),
        CreatedAt DATETIME2 DEFAULT GETDATE()
    );
    
    INSERT INTO TestConnection (TestMessage) VALUES ('Connection Test Successful to Test_IPI!');
    
    SELECT * FROM TestConnection;
    
    -- Clean up test table
    DROP TABLE TestConnection;
    
    PRINT 'Connection test to Test_IPI completed successfully!';
END
ELSE
BEGIN
    PRINT 'Test table already exists. Connection to Test_IPI is working.';
END
