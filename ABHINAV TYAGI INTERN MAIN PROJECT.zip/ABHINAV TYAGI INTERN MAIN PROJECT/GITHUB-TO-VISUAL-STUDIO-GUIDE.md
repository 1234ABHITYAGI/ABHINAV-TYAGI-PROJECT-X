# GitHub to Visual Studio - Direct Setup Guide

## **🚀 Quick Setup Process**

### **Step 1: Install Required Software**
1. **Visual Studio 2022 Community** (FREE)
   - Download: https://visualstudio.microsoft.com/vs/community/
   - Install with: ASP.NET and web development workload

2. **SQL Server Management Studio** (FREE)
   - Download: https://aka.ms/ssmsfullsetup

3. **Git** (Usually comes with Visual Studio, but if needed)
   - Download: https://git-scm.com/download/win

### **Step 2: Clone from GitHub (3 Methods)**

#### **Method A: Using Visual Studio (Easiest)**
1. Open Visual Studio 2022
2. Click **"Clone a repository"**
3. Enter your GitHub repository URL
4. Choose local path: `C:\Projects\ConferenceRoomBooking`
5. Click **Clone**
6. Visual Studio will automatically open the project!

#### **Method B: Using Command Line**
\`\`\`bash
# Open Command Prompt or PowerShell
cd C:\
mkdir Projects
cd Projects
git clone [YOUR_GITHUB_REPOSITORY_URL]
cd ConferenceRoomBooking
start ConferenceRoomBooking.sln
\`\`\`

#### **Method C: Download ZIP from GitHub**
1. Go to your GitHub repository
2. Click **Code** → **Download ZIP**
3. Extract to `C:\Projects\ConferenceRoomBooking`
4. Open `ConferenceRoomBooking.sln` in Visual Studio

### **Step 3: Restore NuGet Packages (Automatic)**
- Visual Studio will automatically restore all required packages
- If not, right-click solution → **Restore NuGet Packages**

### **Step 4: Set Up Database**
1. Open SQL Server Management Studio
2. Connect to: **10.7.74.186** (User: INTERN, Password: Intern@123)
3. Run script: `scripts/complete-database-setup.sql`

### **Step 5: Run the Application**
1. Press **F5** in Visual Studio
2. Login with: **abhinav / admin123**

## **✅ That's It! No Manual File Copying Needed!**
