# Setting Up Your GitHub Repository

## **📁 Repository Structure for GitHub**

When you upload to GitHub, make sure your repository has this structure:

\`\`\`
ConferenceRoomBooking/
├── Controllers/
├── Models/
├── Data/
├── Services/
├── Views/
├── wwwroot/
├── scripts/
├── appsettings.json
├── Program.cs
├── ConferenceRoomBooking.csproj
├── ConferenceRoomBooking.sln
├── README.md
└── .gitignore
\`\`\`

## **📝 Important Files to Include:**

### **Essential Project Files:**
- ✅ `ConferenceRoomBooking.sln` (Solution file)
- ✅ `ConferenceRoomBooking.csproj` (Project file)
- ✅ `appsettings.json` (Configuration)
- ✅ All `.cs` files (Controllers, Models, etc.)
- ✅ All `.cshtml` files (Views)
- ✅ `scripts/` folder (Database scripts)

### **Files to Exclude (.gitignore):**
\`\`\`gitignore
## Visual Studio files
bin/
obj/
.vs/
*.user
*.suo
*.cache

## Database
*.mdf
*.ldf

## Logs
logs/
*.log

## NuGet
packages/
*.nupkg
\`\`\`

## **🔗 GitHub Repository URL Format:**
\`\`\`
https://github.com/[USERNAME]/[REPOSITORY-NAME].git
\`\`\`

Example:
\`\`\`
https://github.com/AbhinavTyagi2612/ConferenceRoomBooking.git
