using Microsoft.EntityFrameworkCore;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using ConferenceRoomBooking.Services;
using ConferenceRoomBooking.Middleware;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add Entity Framework
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add session support
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Add custom services
builder.Services.AddScoped<IPermissionService, PermissionService>();
builder.Services.AddScoped<IAdminAccessService, AdminAccessService>();
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// Configure HttpContext accessor
var httpContextAccessor = app.Services.GetRequiredService<IHttpContextAccessor>();
ConferenceRoomBooking.Services.HttpContext.Configure(httpContextAccessor);

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Add session middleware
app.UseSession();

// Add custom middleware
app.UseMiddleware<AdminAccessMiddleware>();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

// Seed database
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    try
    {
        context.Database.EnsureCreated();
        DatabaseSeeder.SeedData(context);
    }
    catch (Exception ex)
    {
        var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred while seeding the database.");
    }
}

app.Run();

public static class DatabaseSeeder
{
    public static void SeedData(ApplicationDbContext context)
    {
        // Add users with Indian names
        var users = new[]
        {
            new User 
            { 
                Name = "Rajesh Kumar", 
                Email = "rajesh.kumar@company.com", 
                Username = "rajesh", 
                Password = "admin123", 
                IsAdmin = true 
            },
            new User 
            { 
                Name = "Abhinav Sharma", 
                Email = "abhinav.sharma@company.com", 
                Username = "abhinav", 
                Password = "admin123", 
                IsAdmin = true 
            },
            new User 
            { 
                Name = "Rohit Gupta", 
                Email = "rohit.gupta@company.com", 
                Username = "rohit", 
                Password = "user123", 
                IsAdmin = false 
            },
            new User 
            { 
                Name = "Priya Singh", 
                Email = "priya.singh@company.com", 
                Username = "priya", 
                Password = "user123", 
                IsAdmin = false 
            },
            new User 
            { 
                Name = "Vikram Patel", 
                Email = "vikram.patel@company.com", 
                Username = "vikram", 
                Password = "user123", 
                IsAdmin = false 
            },
            new User 
            { 
                Name = "Anita Verma", 
                Email = "anita.verma@company.com", 
                Username = "anita", 
                Password = "user123", 
                IsAdmin = false 
            },
            new User 
            { 
                Name = "Suresh Reddy", 
                Email = "suresh.reddy@company.com", 
                Username = "suresh", 
                Password = "user123", 
                IsAdmin = false 
            },
            new User 
            { 
                Name = "Kavya Nair", 
                Email = "kavya.nair@company.com", 
                Username = "kavya", 
                Password = "user123", 
                IsAdmin = false 
            }
        };
        
        context.Users.AddRange(users);
        context.SaveChanges();
        
        // Add conference rooms with Indian office context
        var rooms = new[]
        {
            new ConferenceRoom 
            { 
                Name = "Ganga Conference Room", 
                Description = "Executive meeting room with video conferencing facilities", 
                Capacity = 12, 
                Location = "10th Floor, Tower A" 
            },
            new ConferenceRoom 
            { 
                Name = "Yamuna Meeting Hall", 
                Description = "Large conference room with presentation equipment", 
                Capacity = 20, 
                Location = "5th Floor, Tower B" 
            },
            new ConferenceRoom 
            { 
                Name = "Saraswati Discussion Room", 
                Description = "Medium meeting room with whiteboard and projector", 
                Capacity = 8, 
                Location = "3rd Floor, Tower A" 
            },
            new ConferenceRoom 
            { 
                Name = "Kaveri Training Room", 
                Description = "Training room with modern AV equipment", 
                Capacity = 30, 
                Location = "2nd Floor, Training Wing" 
            },
            new ConferenceRoom 
            { 
                Name = "Narmada Boardroom", 
                Description = "Premium boardroom for executive meetings", 
                Capacity = 15, 
                Location = "12th Floor, Executive Wing" 
            },
            new ConferenceRoom 
            { 
                Name = "Godavari Innovation Lab", 
                Description = "Creative space with flexible seating and collaboration tools", 
                Capacity = 10, 
                Location = "4th Floor, Innovation Center" 
            }
        };
        
        context.ConferenceRooms.AddRange(rooms);
        context.SaveChanges();
    }
}
